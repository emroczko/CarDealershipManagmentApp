#include "person.h"

People::People()
{

}
