#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
//#include "mainwindow2.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots:

    bool on_pushButton_clicked();
    bool on_pushButton_pressed();
private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
