Projekt SALON SAMOCHODOWY:
Wykonałem projekt, który będzie pozwalał zarządzać salonem samochodowym. 
Klasy obecne w projekcie na dzień 16.04.2019:
-MainObjectShop - Głowna klasa programu, można dodawać samochody do salonu, pracowników, mozna laczyc dwa salony w jeden, operator usuwający auto jeśli klient ma odpowiednio dużo pieniędzy
-Employee - Pracownicy - mozna podnosic wynagrodzenie i porównywać pracowników
-Car - Samochód - mozna stworzyc auto, podnieść cene, zmniejszyc i porownać auta
-Customer - można dać klientowi więcej lub mniej pieniędzy na zakupy
-Locations - operator porównania i przypisania


